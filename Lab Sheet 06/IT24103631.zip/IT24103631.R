setwd("C:\\Users\\DULITHMA\\Desktop\\IT24103631")
#Question 1
# 1. Binomial Distribution
# 2. P(X>=47) --> 1 - P(X<=46)
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

#Question 2
# 1. Number of Customer calls per hour
# 2. Poisson Distribution
# 3. P(X=15)
dpois(15, 12)
